import { Availabledates } from './availabledates';

describe('Availabledates', () => {
  it('should create an instance', () => {
    expect(new Availabledates()).toBeTruthy();
  });
});
