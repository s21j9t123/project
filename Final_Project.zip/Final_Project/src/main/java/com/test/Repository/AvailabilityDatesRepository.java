package com.test.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.test.Model.AvailabilityDates;

@Repository
public interface AvailabilityDatesRepository extends JpaRepository<AvailabilityDates, Integer> 
{

}
