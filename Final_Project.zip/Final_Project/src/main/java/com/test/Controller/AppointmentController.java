package com.test.Controller;

import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.test.Model.Appointment;
import com.test.Services.AppointmentService;



@RestController
@CrossOrigin("*")
@RequestMapping("/")
public class AppointmentController {
	
	@Autowired
    private AppointmentService appointmentService;

    @GetMapping("appointment")
    public List<Appointment> list(){
        return appointmentService.listAll();
    }


    @GetMapping("appointment/{id}")
    public ResponseEntity<Appointment> get(@PathVariable Integer id){
        try{
            Appointment appointment  = appointmentService.get(id);
            return new ResponseEntity<Appointment>(appointment, HttpStatus.OK);

        } catch (NoSuchElementException e){
            return new ResponseEntity<Appointment>(HttpStatus.NOT_FOUND);
        }
    }

    @PostMapping("appointment")
    public ResponseEntity<Appointment> add(@RequestBody Appointment appointment){
        appointmentService.save(appointment);
        return new ResponseEntity<Appointment>(appointment,HttpStatus.CREATED);
    }


    @PutMapping("appointment")
    public ResponseEntity<?> update(@RequestBody Appointment appointment) {
        try {
            Appointment existAppointment = appointmentService.update(appointment);
            appointmentService.save(appointment);
            return new ResponseEntity<>(HttpStatus.OK);
        } catch (NoSuchElementException e) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("appointment/{id}")
    public void delete(@PathVariable Integer id) {
        appointmentService.delete(id);
    }


}
